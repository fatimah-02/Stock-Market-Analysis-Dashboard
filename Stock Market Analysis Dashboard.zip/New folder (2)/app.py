import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# -------------------------------
# Page config & styling
# -------------------------------
st.set_page_config(page_title="Tesla Stock Dashboard", layout="wide")

st.markdown(
    """
    <style>
    body {background: linear-gradient(135deg,#081b2a 0%, #022b3a 100%);} 
    .stApp { color: #e6eef8; }
    .big-title {font-size:42px !important; font-weight:700; color:#FFD166}
    .subtitle {color:#BEE3F8;}
    .metric-card {background:rgba(255,255,255,0.02); padding:12px; border-radius:8px}
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown("<div class='big-title'>📈 Tesla Stock Dashboard (2016-2021)</div>", unsafe_allow_html=True)


# -------------------------------
# Load Data
# -------------------------------
@st.cache_data
def load_data():
    df = pd.read_csv("TSLA.csv")
    df['Date'] = pd.to_datetime(df['Date'])
    df = df.sort_values('Date')
    df['Daily Return'] = df['Close'].pct_change()
    df['50_MA'] = df['Close'].rolling(window=50).mean()
    df['200_MA'] = df['Close'].rolling(window=200).mean()
    return df

df = load_data()

# -------------------------------
# Top filters (no sidebar)
# -------------------------------
fcol, tcol = st.columns([3,1])
with fcol:
    start_date = st.date_input("Start Date", df['Date'].min())
    end_date = st.date_input("End Date", df['Date'].max())
with tcol:
    theme = st.selectbox("Theme", ["Dark", "Light"], index=0)

template = 'plotly_dark' if theme == 'Dark' else 'plotly_white'

mask = (df['Date'] >= pd.to_datetime(start_date)) & (df['Date'] <= pd.to_datetime(end_date))
filtered_df = df.loc[mask].copy()

if filtered_df.empty:
    st.warning("No data for the selected date range.")
    st.stop()


# -------------------------------
# KPIs (colorful)
# -------------------------------
st.subheader("Key Metrics")
col1, col2, col3, col4, col5 = st.columns(5)
latest = filtered_df['Close'].iloc[-1]
highest = filtered_df['High'].max()
lowest = filtered_df['Low'].min()
avg_return = filtered_df['Daily Return'].mean() * 100
total_vol = filtered_df['Volume'].sum()

period_change = (latest / filtered_df['Close'].iloc[0] - 1) * 100

col1.metric("Latest Close", f"${latest:.2f}", delta=f"{period_change:.2f}%")
col2.metric("Highest Price", f"${highest:.2f}")
col3.metric("Lowest Price", f"${lowest:.2f}")
col4.metric("Average Daily Return", f"{avg_return:.2f}%")
col5.metric("Total Volume", f"{total_vol:,.0f}")


# Color sequence for consistency
color_seq = ['#FFD166', '#06D6A0', '#118AB2', '#EF476F', '#06D6A0']

# -------------------------------
# Closing Price Line Chart
# -------------------------------
st.subheader("📊 Closing Price Over Time")
fig_close = px.line(filtered_df, x='Date', y='Close', title="Closing Price Over Time", template=template, color_discrete_sequence=[color_seq[2]])
fig_close.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
st.plotly_chart(fig_close, use_container_width=True)


# -------------------------------
# Candlestick Chart
# -------------------------------
st.subheader("🕯️ Candlestick Chart")
fig_candle = go.Figure(data=[go.Candlestick(
    x=filtered_df['Date'],
    open=filtered_df['Open'],
    high=filtered_df['High'],
    low=filtered_df['Low'],
    close=filtered_df['Close'],
    increasing_line_color='#06D6A0',
    decreasing_line_color='#EF476F'
)])
fig_candle.update_layout(title='Candlestick Chart', xaxis_rangeslider_visible=False, template=template)
st.plotly_chart(fig_candle, use_container_width=True)


# -------------------------------
# Moving Averages
# -------------------------------
st.subheader("📈 Moving Averages (50-day & 200-day)")
fig_ma = go.Figure()
fig_ma.add_trace(go.Scatter(x=filtered_df['Date'], y=filtered_df['Close'], name='Close', line=dict(color=color_seq[2], width=1)))
fig_ma.add_trace(go.Scatter(x=filtered_df['Date'], y=filtered_df['50_MA'], name='50-day MA', line=dict(color=color_seq[0], width=2)))
fig_ma.add_trace(go.Scatter(x=filtered_df['Date'], y=filtered_df['200_MA'], name='200-day MA', line=dict(color=color_seq[1], width=2)))
fig_ma.update_layout(template=template)
st.plotly_chart(fig_ma, use_container_width=True)


# -------------------------------
# Volume Analysis
# -------------------------------
st.subheader("📊 Trading Volume")
fig_volume = px.bar(filtered_df, x='Date', y='Volume', title="Daily Trading Volume", template=template, color_discrete_sequence=[color_seq[3]])
fig_volume.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
st.plotly_chart(fig_volume, use_container_width=True)


# -------------------------------
# Daily Returns & Volatility
# -------------------------------
st.subheader("📉 Daily Returns & Volatility")
fig_return = px.histogram(filtered_df, x='Daily Return', nbins=50, title="Histogram of Daily Returns", template=template, color_discrete_sequence=[color_seq[4]])
st.plotly_chart(fig_return, use_container_width=True)

# Rolling volatility (21-day)
filtered_df['Volatility'] = filtered_df['Daily Return'].rolling(window=21).std() * (252**0.5)
fig_vol = px.line(filtered_df, x='Date', y='Volatility', title="Rolling Volatility (21-day)", template=template, color_discrete_sequence=[color_seq[1]])
st.plotly_chart(fig_vol, use_container_width=True)


# -------------------------------
# Raw data view
# -------------------------------
with st.expander("View Raw Data (first 200 rows)", expanded=False):
    st.dataframe(filtered_df.head(200))

